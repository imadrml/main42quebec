/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   testeg.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: eguefif <eguefif@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/14 17:21:51 by eguefif           #+#    #+#             */
/*   Updated: 2023/09/19 09:15:24 by eguefif          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <string.h>

int	same_sign(int a, int b)
{
	if ((a < 0 && b < 0) || (a > 0 && b > 0))
		return (0);
	if (a == b)
		return (0);
	return (1);
}

int	ft_strncmp(char *s1, char *s2, unsigned int n);

int	main(void)
{
	int		d;

	d = 0;
	printf("\e[0;33mTesting n = 0\n");
	if (ft_strncmp("", "", 0) !=  strncmp("", "", 0))
	{
		printf("\e[0;31mTest failed\n");
		d++;
	}
	if (ft_strncmp("hello", "hello", 0) !=  strncmp("hello", "hello", 0))
	{
		printf("\e[0;31mTest failed\n");
		d++;
	}
	if (ft_strncmp("学生", "学生", 0) !=  strncmp("学生", "学生", 0))
	{
		printf("\e[0;31mTest failed\n");
		d++;
	}
	if (ft_strncmp("hell", "hello", 0) !=  strncmp("hell", "hello", 0))
	{
		printf("\e[0;31mTest failed\n");
		d++;
	}
	if (ft_strncmp("helloo", "hello",0 ) !=  strncmp("helloo", "hello", 0))
	{
		printf("\e[0;31mTest failed\n");
		d++;
	}
	if (ft_strncmp("hella", "hello",0 ) !=  strncmp("hella", "hello", 0))
	{
		printf("\e[0;31mTest failed\n");
		d++;
	}
	if (ft_strncmp("hellz", "hello",0 ) !=  strncmp("hellz", "hello", 0))
	{
		printf("\e[0;31mTest failed\n");
		d++;
	}
	if (ft_strncmp("hell", "", 0 ) !=  strncmp("hell", "", 0))
	{
		printf("\e[0;31mTest failed\n");
		d++;
	}
	if (ft_strncmp("", "hell", 0 ) !=  strncmp("", "hell", 0))
	{
		printf("\e[0;31mTest failed\n");
		d++;
	}
	if (ft_strncmp("aaa", "aaa\200", 0) !=  strncmp("aaa", "aaa\200", 0))
	{
		printf("\e[0;31mTest failed\n");
		d++;
	}
	if (ft_strncmp("aaaa", "aaa\200", 0) !=  strncmp("aaaa", "aaa\200", 0))
	{
		printf("\e[0;31mTest failed\n");
		d++;
	}
	if (ft_strncmp("aaa", "\255", 0) !=  strncmp("aaa", "\255", 0))
	{
		printf("\e[0;31mTest failed\n");
		d++;
	}
	if (ft_strncmp("aaa", "aaa\255", 0) !=  strncmp("aaa", "aaa\255", 0))
	{
		printf("\e[0;31mTest failed\n");
		d++;
	}

	printf("\e[0;33mTesting n > size\n");
	if (same_sign(ft_strncmp("", "", 10) ,  strncmp("", "", 10)))
	{
		printf("\e[0;31mTest failed\n");
		d++;
	}
	if (same_sign(ft_strncmp("hello", "hello", 10) ,  strncmp("hello", "hello", 10)))
	{
		printf("\e[0;31mTest failed\n");
		d++;
	}
	if (same_sign(ft_strncmp("学生", "学生", 10) ,  strncmp("学生", "学生", 10)))
	{
		printf("\e[0;31mTest failed\n");
		d++;
	}
	if (same_sign(ft_strncmp("hell", "hello", 10) ,  strncmp("hell", "hello", 10)))
	{
		printf("\e[0;31mTest failed\n");
		d++;
	}
	if (same_sign(ft_strncmp("helloo", "hello", 10) ,  strncmp("helloo", "hello", 10)))
	{
		printf("\e[0;31mTest failed\n");
		d++;
	}
	if (same_sign(ft_strncmp("hella", "hello", 10 ) ,  strncmp("hella", "hello", 10)))
	{
		printf("\e[0;31mTest failed\n");
		d++;
	}
	if (same_sign(ft_strncmp("hellz", "hello", 10 ) ,  strncmp("hellz", "hello", 10)))
	{
		printf("\e[0;31mTest failed\n");
		d++;
	}
	if (same_sign(ft_strncmp("hell", "", 10) ,  strncmp("hell", "", 10)))
	{
		printf("\e[0;31mTest failed\n");
		d++;
	}
	if (same_sign(ft_strncmp("", "hell", 10) ,  strncmp("", "hell", 10)))
	{
		printf("\e[0;31mTest failed\n");
		d++;
	}
	if (same_sign(ft_strncmp("aaa", "aaa\200", 10) ,  strncmp("aaa", "aaa\200", 10)))
	{
		printf("\e[0;31mTest failed\n");
		d++;
	}
	if (same_sign(ft_strncmp("aaaa", "aaa\200", 10) ,  strncmp("aaaa", "aaa\200", 10)))
	{
		printf("\e[0;31mTest failed\n");
		d++;
	}
	if (same_sign(ft_strncmp("aaa", "\255", 10) ,  strncmp("aaa", "\255", 10)))
	{
		printf("\e[0;31mTest failed\n");
		d++;
	}
	if (same_sign(ft_strncmp("aaa", "aaa\255", 10) ,  strncmp("aaa", "aaa\255", 10)))
	{
		printf("\e[0;31mTest failed\n");
		d++;
	}
	
	printf("\e[0;33mTesting n == size\n");
	if (same_sign(ft_strncmp("", "", 0) ,  strncmp("", "", 0)))
	{
		printf("\e[0;31mTest failed\n");
		d++;
	}
	if (same_sign(ft_strncmp("hello", "hello", 5) ,  strncmp("hello", "hello", 5)))
	{
		printf("\e[0;31mTest failed\n");
		d++;
	}
	if (same_sign(ft_strncmp("学生", "学生", 20) ,  strncmp("学生", "学生", 20)))
	{
		printf("\e[0;31mTest failed\n");
		d++;
	}
	if (same_sign(ft_strncmp("hell", "hello", 5) ,  strncmp("hell", "hello", 5)))
	{
		printf("\e[0;31mTest failed\n");
		d++;
	}
	if (same_sign(ft_strncmp("helloo", "hello", 6) ,  strncmp("helloo", "hello", 6)))
	{
		printf("\e[0;31mTest failed\n");
		d++;
	}
	if (same_sign(ft_strncmp("hella", "hello", 5 ) ,  strncmp("hella", "hello", 5)))
	{
		printf("\e[0;31mTest failed\n");
		d++;
	}
	if (same_sign(ft_strncmp("hellz", "hello", 5 ) ,  strncmp("hellz", "hello", 5)))
	{
		printf("\e[0;31mTest failed\n");
		d++;
	}
	if (same_sign(ft_strncmp("hell", "", 4) ,  strncmp("hell", "", 4)))
	{
		printf("\e[0;31mTest failed\n");
		d++;
	}
	if (same_sign(ft_strncmp("", "hell", 4) ,  strncmp("", "hell", 4)))
	{
		printf("\e[0;31mTest failed\n");
		d++;
	}
	if (same_sign(ft_strncmp("aaa", "aaa\200", 4) ,  strncmp("aaa", "aaa\200", 4)))
	{
		printf("\e[0;31mTest failed\n");
		d++;
	}
	if (same_sign(ft_strncmp("aaaa", "aaa\200", 4) ,  strncmp("aaaa", "aaa\200", 4)))
	{
		printf("\e[0;31mTest failed\n");
		d++;
	}
	if (same_sign(ft_strncmp("aaa", "\255", 3) ,  strncmp("aaa", "\255", 3)))
	{
		printf("\e[0;31mTest failed\n");
		d++;
	}
	if (same_sign(ft_strncmp("aaa", "aaa\255", 4) ,  strncmp("aaa", "aaa\255", 4)))
	{
		printf("\e[0;31mTest failed\n");
		d++;
	}

	if (d == 0)
		printf("\e[0;32mTest passed\n");
	return (0);
}

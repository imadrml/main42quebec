/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   testeg.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: eguefif <eguefif@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/14 17:21:51 by eguefif           #+#    #+#             */
/*   Updated: 2023/09/18 19:15:58 by eguefif          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char	*ft_strcat(char *dest, char *src);

int	main(void)
{
	char	src[] = ", I love what I do";
	char	temp[] = "Hello my friend";
	char	*dest;
	char	*destcmp;

	dest = (char *) malloc(sizeof(src) - 1 + sizeof(temp));
	destcmp = (char *) malloc(sizeof(src) - 1 + sizeof(temp));
	strcpy(dest, temp);
	strcpy(destcmp, temp);
	ft_strcat(dest, src);
	strcat(destcmp, src);
	if (strcmp(destcmp, dest) == 0 && dest[strlen(dest)] == '\0')
		printf("\e[0;32mTest passed\n");
	else
	{
		printf("\e[0;31mTest failed\n");
		printf("Yours : %s\n", dest);
		printf("strcat: %s\n", destcmp);
	}
	//The space is much bigger
	dest = (char *) malloc(sizeof(src) + sizeof(temp) + 10);
	destcmp = (char *) malloc(sizeof(src) + sizeof(temp) + 10);
	strcpy(dest, temp);
	strcpy(destcmp, temp);
	ft_strcat(dest, src);
	strcat(destcmp, src);
	if (strcmp(destcmp, dest) == 0 && dest[strlen(dest)] == '\0')
		printf("\e[0;32mTest passed\n");
	else
	{
		printf("\e[0;31mTest failed\n");
		printf("Yours : %s\n", dest);
		printf("strcat: %s\n", destcmp);
	}
	
	// With an empty src
	char	src3[] = "";
	char	temp3[] = "Hello my friend";
	char	*dest3;
	char	*destcmp3;

	dest3 = (char *) malloc(sizeof(src3) + sizeof(temp3));
	destcmp3 = (char *) malloc(sizeof(src3) + sizeof(temp3));
	strcpy(dest3, temp3);
	strcpy(destcmp3, temp3);
	ft_strcat(dest3, src3);
	strcat(destcmp3, src3);
	if (strcmp(destcmp3, dest3) == 0 && dest3[strlen(dest3)] == '\0')
		printf("\e[0;32mTest passed\n");
	else
	{
		printf("\e[0;31mTest failed\n");
		printf("Yours : %s\n", dest3);
		printf("strcat: %s\n", destcmp3);
	}
	return (0);
}

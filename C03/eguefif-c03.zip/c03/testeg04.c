/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   testeg.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: eguefif <eguefif@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/14 17:21:51 by eguefif           #+#    #+#             */
/*   Updated: 2023/09/18 19:21:27 by eguefif          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <string.h>

char	*ft_strstr(char *str, char *to_find);

int	main(void)
{
	char	*c;
	char	*d;

	// Found a string
	c = strstr("Je suis une string de test", "rin");
	d = ft_strstr("Je suis une string de test", "rin");
	if (c == d)
		printf("\e[0;32mTest passed\n");
	else
		printf("\e[0;31mTest failed. Your address: %lu should be: %lu\n", (unsigned long int) d, (unsigned long int) c);

	// No string found
	c = strstr("Je suis une string de test", "trou");
	d = ft_strstr("Je suis une string de test", "trou");
	if (c == d)
		printf("\e[0;32mTest passed\n");
	else
		printf("\e[0;31mTest failed. Your address: %lu should be: %lu\n", (unsigned long int) d, (unsigned long int) c);

	//	find is empty 
	c = strstr("Je suis une string de test", "");
	d = ft_strstr("Je suis une string de test", "");
	if (c == d)
		printf("\e[0;32mTest passed\n");
	else
		printf("\e[0;31mTest failed. Your address: %lu should be: %lu\n", (unsigned long int) d, (unsigned long int) c);

	//	to find is bigger than str
	c = strstr("Je sui", "Je suis");
	d = ft_strstr("Je sui", "Je suis");
	if (c == d)
		printf("\e[0;32mTest passed\n");
	else
		printf("\e[0;31mTest failed. Your address: %lu should be: %lu\n", (unsigned long int) d, (unsigned long int) c);
	return (0);
}

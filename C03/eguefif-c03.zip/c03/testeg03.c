/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   testeg.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: eguefif <eguefif@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/14 17:21:51 by eguefif           #+#    #+#             */
/*   Updated: 2023/09/18 19:18:07 by eguefif          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char	*ft_strncat(char *dest, char *src, unsigned int nb);

int	main(void)
{
	char	src[] = ", I love what I do";
	char	temp[] = "Hello my friend";
	char	*dest;
	char	*destcmp;

	// Test: everything is correct
	dest = (char *) malloc(sizeof(src) + sizeof(temp) - 1);
	destcmp = (char *) malloc(sizeof(src) + sizeof(temp) - 1);
	strcpy(dest, temp);
	strcpy(destcmp, temp);
	ft_strncat(dest, src, strlen(src));
	strncat(destcmp, src, strlen(src));
	if (strcmp(destcmp, dest) == 0 && dest[strlen(dest)] == '\0')
		printf("\e[0;32mTest passed\n");
	else
	{
		printf("\e[0;31mTest failed\n");
		printf("Yours : %s\n", dest);
		printf("strncat: %s\n", destcmp);
	}
	
	// Test: their is more to copy than n
	dest = (char *) malloc(sizeof(src) + sizeof(temp));
	destcmp = (char *) malloc(sizeof(src) + sizeof(temp));
	strcpy(dest, temp);
	strcpy(destcmp, temp);
	ft_strncat(dest, src, 4);
	strncat(destcmp, src, 4);
	if (strcmp(destcmp, dest) == 0 && dest[strlen(dest)] == '\0')
		printf("\e[0;32mTest passed\n");
	else
	{
		printf("\e[0;31mTest failed\n");
		printf("Yours : %s\n", dest);
		printf("strncat: %s\n", destcmp);
	}
	return (0);
}

/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   testeg.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: eguefif <eguefif@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/14 17:21:51 by eguefif           #+#    #+#             */
/*   Updated: 2023/09/18 19:04:07 by eguefif          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <string.h>

int	ft_strcmp(char *s1, char *s2);

int	main(void)
{
	int		i;
	int		a;

	//equal
	i = ft_strcmp("aaaa", "aaaa");
	a = strcmp("aaaa", "aaaa");
	if (i == a)
		printf("\e[0;32mTest passed\n");
	else
	{
		printf("\e[0;31mTest failed");
		printf("Yours: %d should be %d\n\e[0;37m", i, a);
	}
	//Less than size
	i = ft_strcmp("aaa", "aaaa");
	a = strcmp("aaa", "aaaa");
	if (i == a)
		printf("\e[0;32mTest passed\n");
	else
	{
		printf("\e[0;31mTest failed");
		printf("Yours: %d should be %d\n\e[0;37m", i, a);
	}

	//bigger than letter
	i = ft_strcmp("aaad", "aaaa");
	a = strcmp("aaad", "aaaa");
	if (i == a)
		printf("\e[0;32mTest passed\n");
	else
	{
		printf("\e[0;31mTest failed");
		printf("Yours: %d should be %d\n\e[0;37m", i, a);
	}

	//less than letter
	i = ft_strcmp("aaad", "aaai");
	a = strcmp("aaad", "aaai");
	if (i == a)
		printf("\e[0;32mTest passed\n");
	else
	{
		printf("\e[0;31mTest failed");
		printf("Yours: %d should be %d\n\e[0;37m", i, a);
	}
	//greater than, size
	i = ft_strcmp("aaad", "aaa");
	a = strcmp("aaad", "aaa");
	if (i == a)
		printf("\e[0;32mTest passed\n");
	else
	{
		printf("\e[0;31mTest failed");
		printf("Yours: %d should be %d\n\e[0;37m", i, a);
	}
	return (0);
}

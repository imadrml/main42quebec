#include <stdio.h>

int	ft_strlen(char *str);
int main(void)
{
char s1[] = "imad eddine";
printf("%d", ft_strlen(s1));
return (0);
}
